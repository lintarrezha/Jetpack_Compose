package com.dicoding.submissionjetpackcompose.data.model

data class Hero(
    val id: Long,
    val name: String,
    val image: Int,
    val desc: String
)
