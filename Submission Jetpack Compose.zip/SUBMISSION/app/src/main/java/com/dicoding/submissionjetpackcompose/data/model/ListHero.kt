package com.dicoding.submissionjetpackcompose.data.model

data class ListHero (
    val listHero: Hero,
    val count : Int
)